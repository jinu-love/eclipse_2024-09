package kr.co.beliftech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovaSpringbootServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
